<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

use GuzzleHttp\Client;
use GuzzleHttp\Psr7\HttpFactory;
use OpenTelemetry\Contrib\Otlp\OtlpHttpTransportFactory;
use OpenTelemetry\Contrib\Otlp\SpanExporter;
use OpenTelemetry\SDK\Trace\SpanExporter\ConsoleSpanExporter;
use OpenTelemetry\SDK\Trace\SpanProcessor\SimpleSpanProcessor;
use OpenTelemetry\SDK\Trace\TracerProvider;

class TestController extends BaseController
{
	public function index()
	{
		putenv('OTEL_SERVICE_NAME=wind');
		echo 'Starting OTLP/http Exporter' . PHP_EOL;
		$transport = (new OtlpHttpTransportFactory())->create('http://localhost:4318/v1/traces', 'application/x-protobuf');
		$exporter = new SpanExporter($transport);

		$tracerProvider =  new TracerProvider(
			new SimpleSpanProcessor(
				$exporter
			)
		);

		$tracer = $tracerProvider->getTracer('io.opentelemetry.contrib.php');

		$rootSpan = $tracer->spanBuilder('root')->startSpan();
		$rootScope = $rootSpan->activate();
		$span1 = $tracer->spanBuilder('foo')->startSpan();
		$scope = $span1->activate();
			$span2 = $tracer->spanBuilder('bar')->startSpan();
				$span3 = $tracer->spanBuilder('hehe')->startSpan();
				$scope3 = $span3->activate();

					//file_get_contents("https://baidu.com");

					$span4 = $tracer->spanBuilder('haha')->startSpan();

					//file_get_contents("https://jd.com");

					$span4->end();

				$span3->end();
				$scope3->detach();
			$span2->end();
		$span1->end();
		$scope->detach();
		$rootSpan->end();
		$rootScope->detach();
	}
}
