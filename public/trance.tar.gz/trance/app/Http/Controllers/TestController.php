<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

use App\Facades\Trance;
use App\Models\Test;


class TestController extends BaseController
{
	public function index()
	{
        echo 'controller'.PHP_EOL;
        Trance::start('apple');
            $model = new Test;
            $model->test();
        Trance::stop('apple');
        return;

        //$trancer = app()->make('trance');
        //$trancer->start('apple');
        usleep(1000);
        $trancer->stop('apple');

        $trancer->start('orange');
        usleep(2000);

            $trancer->start('fig');
            usleep(3000);

                    $trancer->start('kiwi');
                    usleep(4000);
                    $trancer->stop('kiwi');

            $trancer->stop('fig');

        $trancer->stop('orange');
        echo date('Y-m-d H:i:s', time());
        echo 'span tranced';
	}
}
