<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Facades\Trance;

class Test extends Model
{
    use HasFactory;

    function test() {
        echo 'model'.PHP_EOL;
        Trance::start('cherry');
        echo date('H:i:s', time());
        Trance::stop('cherry');

        Trance::start('pear');
        echo date('H:i:s', time());
        Trance::stop('pear');
    }
}
